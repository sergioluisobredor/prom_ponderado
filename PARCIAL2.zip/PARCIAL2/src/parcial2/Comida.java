/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2;

/**
 *
 * @author estudiante
 */
public class Comida implements Estadores{
  private int hamburguesa=5000;
  private int perro=5000;
    private int pizza=4000; 
    
    @Override
    public void atiende(Persona persona) {
        System.out.println("Hora Desayuno");
    }

    public int getHamburguesa() {
        return hamburguesa;
    }

    public void setHamburguesa(int hamburguesa) {
        this.hamburguesa = hamburguesa;
    }

    public int getPerro() {
        return perro;
    }

    public void setPerro(int perro) {
        this.perro = perro;
    }

    public int getPizza() {
        return pizza;
    }

    public void setPizza(int pizza) {
        this.pizza = pizza;
    }
 
    
}
