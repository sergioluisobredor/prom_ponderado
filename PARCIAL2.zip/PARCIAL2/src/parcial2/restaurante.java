/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2;

/**
 *
 * @author estudiante
 */
public class restaurante {
        private String nombre;
        private String direccion;
        private Pedido pedido= new Pedido();
    
     
    
     
 
    public void desayuno(){
        pedido.MetoDesayuno();
    }
    
    public void almuerzo(){
        pedido.MetoAlmuerzo();
    }
    
    public void cerrar(){
        pedido.Cerrar();
        
    }
    
    public void comida(){
        pedido.MetoComida();
    }

}
