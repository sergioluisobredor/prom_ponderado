package parcial2;




public class Pedido {
    
    private String pedido;
    private Estadores estado;
    
    
     public Pedido(){
        estado =new Desayuno();
    }
    public void Cerrar(){
        estado = new Cerrado();
    }
    
    public void MetoDesayuno(){
        estado = new Desayuno();
    }
    
    public void MetoAlmuerzo(){
        estado = new Almuerzo();
    }
    
   public void MetoComida(){
        estado = new Comida();
    }
    
}