/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2;

/**
 *
 * @author estudiante
 */
public class Desayuno implements Estadores{
       private int desaAmerica=7000;
       private int desaCosteño=9000;

        @Override
    public void atiende(Persona persona) {
        System.out.println("Hora Desayuno");
    }
       


    public int getDesaAmerica() {
        return desaAmerica;
    }

    public void setDesaAmerica(int desaAmerica) {
        this.desaAmerica = desaAmerica;
    }

    public int getDesaCosteño() {
        return desaCosteño;
    }

    public void setDesaCosteño(int desaCosteño) {
        this.desaCosteño = desaCosteño;
    }

    


   
    
}
