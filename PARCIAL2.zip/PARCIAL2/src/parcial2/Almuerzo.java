/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2;

/**
 *
 * @author estudiante
 */
public class Almuerzo implements Estadores{

  private int carne=7000;
  private int pollo=7000;
   private int costillas=7000;

     @Override
    public void atiende(Persona persona) {
        System.out.println("Hora Almuerzo");
    }
   
    public int getCarne() {
        return carne;
    }

    public void setCarne(int carne) {
        this.carne = carne;
    }

    public int getPollo() {
        return pollo;
    }

    public void setPollo(int pollo) {
        this.pollo = pollo;
    }

    public int getCostillas() {
        return costillas;
    }

    public void setCostillas(int costillas) {
        this.costillas = costillas;
    }
}
